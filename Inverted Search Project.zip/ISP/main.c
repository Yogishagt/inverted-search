/*name: YOGISHA GT
DATE: 10-11-2024
project title: Inverted Search*/
#include "main.h"

int main(int argc, char *argv[]){
    // creating a head pointer
    fileName *file_head=NULL;
    fileName *file_head2=NULL;
    // calling readAndValidation function
    if(readAndValidation(argc,argv,&file_head) == SUCCESS){
        printf("INFO: read And Validation is Done\n");
    }
    else{
        printf("INFO: read And Validation is Failure\n");
    }
    // creating the hash table
    main_node *hashtable[27]={NULL};
    int choice;
    // running a loop
    do{
        printf("1. Create DataBase\n2. Display\n3. Search\n4. Save\n5. Update\n6. EXIT\n");
        printf("Enter your choice: ");
        // reading the input from user
        scanf(" %d",&choice);
        printf("choice : %d\n",choice);
        switch (choice){
            case 1:
                // calling create_database function
                if(create_database(hashtable, &file_head, file_head2) == SUCCESS)
                    printf("INFO: Database Created Successfully\n");
                else
                    printf("INFO: Database is not Created!\n");
                break;
            case 2:
                // calling display function
                if(display(hashtable) == SUCCESS)
                    printf("INFO: Display details Successfully\n");
                else
                    printf("INFO: ERROR in Display function!\n");
                break;
            case 3:
                // calling search function
                int ret;
                if( (ret = search(hashtable)) == SUCCESS)
                    printf("INFO: Search details Successfully\n");
                else if(ret == DATA_NOT_FOUND)
                    printf("INFO: Data Not Found\n");
                else
                    printf("INFO: ERROR in search function!\n");
                break;
            case 4:
                // callling save function
                if(save(hashtable) == SUCCESS)
                    printf("INFO: Details save Successfully\n");
                else
                    printf("INFO: ERROR in Save function!\n");
                break;
            case 5:
                // calliing update function
                if(update(hashtable, &file_head2) == SUCCESS ){
                    printf("INFO: Details Update Successfully\n");
                }
                else
                    printf("INFO: ERROR in Update function!\n");
                break;
            case 6:
                // exting form the program
                printf("INFO: EXITing......\n");
                break;
            default:
                break;
        }
    }while(choice != 6);
}