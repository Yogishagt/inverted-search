#ifndef MAIN_H
#define MAIN_H
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include <ctype.h>

#define SUCCESS 1
#define FAILURE -1
#define DATA_NOT_FOUND 2

// char backup[20];

typedef struct Node{
    char file_Name[20];
    struct Node *link;
}fileName;

typedef struct sub{
    int word_count;
    char file_Name[20];
    struct sub *link;
}sub_node;

typedef struct main{
    int fileCount;
    char word[20];
    struct main *main_link;
    sub_node *sub_link;
}main_node;

int readAndValidation(int argc, char *argv[], fileName **file_head);
int insertion_file_name(fileName **file_head,char *fileName_token);

int create_database(main_node *hashtable[], fileName **file_head, fileName *file_head2);
int display(main_node *hashtable[]);
int search(main_node *hashtable[]);
int save(main_node *hashtable[]);
int update(main_node *hashtable[], fileName **file_head2);
#endif