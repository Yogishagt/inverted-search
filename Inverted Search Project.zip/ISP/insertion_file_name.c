#include "main.h"
/*Function to insert a node at the end of a single linked list*/
int insertion_file_name(fileName **file_head,char *fileName_token){
    // creating a filename node dynamically
    fileName *new=malloc(sizeof(fileName));
    // checking if memory is allocated
    if(new == NULL){
        printf("INFO: new node is not created!\n");
        return FAILURE;
    }
    // copying the filename to the new node
    strcpy(new->file_Name, fileName_token);
    new->link=NULL;
    // checking if the file_head is NULL or not
    if(*file_head == NULL){
        *file_head=new;
        printf("INFO: new node inserted successfully\n");
        return SUCCESS;
    }
    else{
        // taking two pointer for traversing
        fileName *duplicate=*file_head;
        fileName *prev=NULL;
        // traversing the linked list
        while(duplicate){
            // checking if filename is already present or not 
            if(strcmp(duplicate->file_Name, fileName_token) == 0){
                printf("INFO: Duplicate File name found!\n");
                return FAILURE;
            }
            // traversing to the next node
            prev=duplicate;
            duplicate=duplicate->link;
        }
        prev->link=new;
        printf("INFO: new node inserted successfully\n");
        return SUCCESS;
    }

}