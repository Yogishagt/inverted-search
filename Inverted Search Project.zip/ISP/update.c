#include "main.h"
/*Function to update the Hash table*/
int update(main_node *hashtable[], fileName **file_head2){
    // running a loop to find hash table is empty or not
    for(int i=0;i<27;i++){
        // checking  hash table is empty or not
        if(hashtable[i] !=NULL){
            printf("ERROR : Hash table is not empty\n");
            return FAILURE;
        }
    }
    // taking a buffer
    char backup[20];
    printf("INFO: Enter the file name to be updated: ");
    // reading the file name from the user
    scanf("%s",backup);
    // checking the file name is valid or not (having .txt extension)
    if(!strstr(backup, ".txt")){
        printf("ERROR: File name is not having .txt extension\n");
        return FAILURE;
    }
    printf("INFO: Entered file having .txt extension\n");
    FILE *file=fopen(backup,"r");
    // checking the file is opened or not
    if(file==NULL){
        printf("ERROR: File is not opened\n");
        return FAILURE;
    }
    printf("INFO: file opend successfully\n");
    // checking file is empty or not
    if(fseek (file, 0, SEEK_END) != 0){
    // if(feof(file) != -1){
        printf("ERROR: File is empty\n");
        return FAILURE;
    }
    printf("INFO: File is not empty\n");
    // moving file stream to starting of the file
    fseek(file,0,SEEK_SET);
    // checking the backup file is start with '#'
    if(fgetc(file) != '#'){
        printf("ERROR: Backup file is not start with '#' \n");
        return FAILURE;
    }
    printf("INFO: Backup file is start with '#' \n");
    // moving file stream to starting of the file
    fseek(file,0,SEEK_SET);
    // taking a buffer
    char buffer[100], *token;
    while(fscanf(file, "%s", buffer) > 0){
        if(buffer[0] == '#'){
            int index = buffer[1] - 48;
            strtok(buffer,";");
            // checking the hash table is empty or not
            if(hashtable[index] == NULL){
                
                // creating a new node's
                main_node *main1=malloc(sizeof(main_node));
                sub_node *sub=malloc(sizeof(sub_node));
                // checking wether node is created or not
                if(main1 == NULL || sub == NULL){
                    printf("INFO: new node is not creater!\n");
                    return FAILURE;
                }
                printf("INFO: main node and sub node is created\n");
                // coping the word to main node
                token = strtok(NULL,";");
                strcpy(main1->word,token);

                // coping the file count
                token=strtok(NULL, ";");
                main1->fileCount=token[0] % 48;

                // creaating link b/w main node and sub node
                main1->sub_link=sub;
                main1->main_link=NULL;

                sub_node *current=sub;
                sub_node *prev=NULL;

                for(int i=1;i<= (token[0] % 48); i++){
                    if(i !=1){
                       sub_node *sub=malloc(sizeof(sub_node)); 
                       current=sub;
                    }
                    printf("HI\n");
                    // coping the filename to sub node
                    token=strtok(NULL, ";");
                    strcpy(current->file_Name,token);

                    // storing the file name to single linked list
                    fileName *new=malloc(sizeof(fileName));
                    // checking wether node is created or not
                    if(new==NULL)
                        return FAILURE;
                    // coping the filename to new node
                    strcpy(new->file_Name, token);
                    new->link=NULL;
                    // checking list is empty or not
                    if(*file_head2 == NULL){
                        *file_head2 = new;
                    }
                    else{
                        fileName *last = *file_head2;
                        // traversing to the last node
                        while(last->link != NULL){
                            last = last->link;
                        }
                        // linking the new node to the last node
                        last->link = new;
                    }
                    // coping the word count form array to node
                    token=strtok(NULL, ";");
                    current->word_count=token[0] % 48;
                    
                    // checking wether prev is null or not
                    if(prev == NULL){
                        // linking the sub node to next sub node
                        current->link=prev;
                        prev=current;
                    }
                    else{
                        // linking the sub node to next sub node
                        prev->link=current;
                        current->link=NULL;
                        prev=current;
                    }
                }
                // storing the main node addrass to hastable
                hashtable[index]=main1;
                printf("INFO: insertion is done\n");
            }
            else{
                // creating a new node's
                main_node *main1=malloc(sizeof(main_node));
                sub_node *sub=malloc(sizeof(sub_node));
                // checking wether node is created or not
                if(main1 == NULL || sub == NULL){
                    printf("INFO: new node is not creater!\n");
                    return FAILURE;
                }
                printf("INFO: main node and sub node is created\n");
                
                // coping the word to main node
                token = strtok(NULL,";");
                strcpy(main1->word,token);

                // updating the main node
                token=strtok(NULL, ";");
                main1->fileCount=token[0] % 48;

                // creaating link b/w main node and sub node
                main1->sub_link=sub;
                main1->main_link=NULL;

                // pointers to insert a sub node at last of single list
                sub_node *current=sub;
                sub_node *prev=NULL;

                for(int i=1;i<= (token[0] % 48); i++){
                    if(i !=1){
                       sub_node *sub=malloc(sizeof(sub_node)); 
                       current=sub;
                    }
                    printf("HI\n");
                    // coping the filename to sub node
                    token=strtok(NULL, ";");
                    strcpy(current->file_Name,token);

                    // storing the file name to single linked list
                    fileName *new=malloc(sizeof(fileName));
                    // checking wether node is created or not
                    if(new==NULL)
                        return FAILURE;
                    // coping the filename to new node
                    strcpy(new->file_Name, token);
                    new->link=NULL;
                    // checking list is empty or not
                    if(*file_head2 == NULL){
                        *file_head2 = new;
                    }
                    else{
                        fileName *last = *file_head2;
                        // traversing to the last node
                        while(last->link != NULL){
                            last = last->link;
                        }
                        // linking the new node to the last node
                        last->link = new;
                    }
                    // coping the word count form array to node
                    token=strtok(NULL, ";");
                    current->word_count=token[0] % 48;

                    // checking prev is null or not
                    if(prev == NULL){
                        // creating link b/w sub node and next sub node
                        current->link=prev;
                        prev=current;
                    }
                    else{
                         // creating link b/w sub node and next sub node
                        prev->link=current;
                        current->link=NULL;
                        prev=current;
                    }
                }

                // declaring two pointers for traversing
                main_node *mtemp=hashtable[index];

                // traversing
                while(mtemp->main_link)
                    mtemp=mtemp->main_link;

                // performing insertion at last
                // creaating link b/w main node and sub node
                mtemp->main_link=main1;
                printf("INFO: insertion is done\n");
            }
        }
    }
    return SUCCESS;
}