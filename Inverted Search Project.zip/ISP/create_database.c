#include "main.h"
/*Function to create a database of all the words in the dictionary file to hash table*/
int create_database(main_node *hashtable[], fileName **file_head, fileName *file_head2){
    // flag to check if the file is name is already in the database
    int flag=0;
    // pointer to the head of the linked list
    fileName *prev=*file_head;
    fileName *temp=*file_head;
    // travsersing the linked list
    while(temp && file_head2!= NULL){
        flag=0;
        fileName *temp2=file_head2;
    // travsersing the linked list
        while(temp2){
            // comparing the file name is prasent in file head2 or not 
            if(strcmp(temp->file_Name, temp2->file_Name) == 0){
                flag=1;
                break;
            }
            // moving a pointer to next node
            temp2=temp2->link;
        }
        if(flag==1){
            if(temp == prev){
                // moving a pointer to next node
                temp = temp->link;
                *file_head=temp;
                // deleting the node from the linked list
                free(prev);
                prev=temp;
            }
            else{
                prev->link = temp->link;
                // deleting the node from the linked list
                free(temp);
                // moving a pointer to next node
                temp=prev->link;
            }
        }
        else{
            // moving a pointer to next node
            prev=temp;
            temp=temp->link;
        }
    }

    temp=*file_head;
    // running a loop
    while(temp){
        // taking a filename form an array
        char *fileName_token=temp->file_Name;
        // declaring a file pointer 
        FILE *file = fopen(fileName_token, "r");
        // checking the file is open or not
        if(file != NULL){
            // taking a buffer
            char word[20];
            // fetching the word from file
            while(fscanf(file,"%s",word) > 0){
                // fuinding the index
                int index=tolower(word[0]) % 97;
                // chceking index is not for alphabet's
                if(index<0 || index> 25)
                    index=26;
                // checking wether the index is empty or not
                if((hashtable[index] == NULL)){
                    // creating a new node's
                    main_node *main1=malloc(sizeof(main_node));
                    sub_node *sub=malloc(sizeof(sub_node));
                    // checking wether node is created or not
                    if(main1 == NULL || sub == NULL){
                        printf("INFO: new node is not creater!\n");
                        return FAILURE;
                    }
                    // updating the main node
                    main1->fileCount=1;
                    // coping the word to main node
                    strcpy(main1->word,word);
                    // creaating link b/w main node and sub node
                    main1->sub_link=sub;
                    main1->main_link=NULL;
                    // updating the sub node
                    sub->word_count=1;
                    // coping the filename to sub node
                    strcpy(sub->file_Name,temp->file_Name);
                    sub->link=NULL;
                    // storing the main node addrass to hastable
                    hashtable[index]=main1;
                }
                else{
                    // declaring two pointers for traversing
                    main_node *mtemp=hashtable[index];
                    main_node *mprev=NULL;
                    int flag=0;
                    // travering
                    while(mtemp!=NULL){
                        // checking wether the word is already present or not
                        if(strcmp(mtemp->word , word) == 0){
                            // declaring two pointers for traversing
                            sub_node *stemp=mtemp->sub_link;
                            sub_node *sprev=NULL;
                            flag=0;
                            // trevering 
                            while(stemp){
                                // checking wether the file name is already present or not
                                if(strcmp(stemp->file_Name , fileName_token) == 0){
                                    // incrementing the word count
                                    stemp->word_count +=1;
                                    flag=1;
                                }
                                // travering forword
                                sprev=stemp;
                                stemp=stemp->link;
                            }
                            // checking temp is reached NULL or not
                            if(flag == 0){
                                // creating a sub node
                                sub_node *sub=malloc(sizeof(sub_node));
                                sub->word_count=1;
                                strcpy(sub->file_Name,temp->file_Name);
                                sub->link=NULL;
                                // creating the link
                                sprev->link=sub;
                                // incrementing the filecount count
                                mtemp->fileCount +=1;
                            }
                            flag=1;
                        }
                        // traversing forword
                        mprev=mtemp;
                        mtemp=mtemp->main_link;
                    }
                    if(flag==0){
                        // creating a new node's
                        main_node *main1=malloc(sizeof(main_node));
                        sub_node *sub=malloc(sizeof(sub_node));
                        if(main1 == NULL || sub == NULL){
                            printf("INFO: new node is not creater!\n");
                            return FAILURE;
                        }
                        // updating the main node
                        main1->fileCount=1;
                        // coping the word to main node
                        strcpy(main1->word,word);
                        // creaating link b/w main node and sub node
                        main1->sub_link=sub;
                        main1->main_link=NULL;
                        mprev->main_link=main1;
                        // updating the sub node
                        sub->word_count=1;
                        // coping the filename to sub node
                        strcpy(sub->file_Name,temp->file_Name);
                        sub->link=NULL;
                    }
                }
            }
        }
        else{
             printf("ERROR: %s Unable to open file\n",fileName_token);
            continue;
        }
        // closing the file
        fclose(file);
        // travering forword
        temp=temp->link;
    }
    return SUCCESS;
}
