#include "main.h"
/*Function to rand and validate the Commad line argument*/
int readAndValidation(int argc, char *argv[], fileName **file_head){
    // checking the argument is passed or not
    if(argc <= 1){
        printf("INFO: Only few Argumrnt is passed\n");
        return FAILURE;
    }
    // running a loop for argc times
    for(int i=1;i<argc;i++){
        // extracting the file name form CLA
        char *fileName_token = argv[i];
        // opening the file
        FILE *file=fopen(fileName_token,"r");
        // checking the file is opened or not
        if(file != NULL){
            printf("INFO: File %s is found\n",fileName_token);
            // checking the file name is valid or not (having .txt extension)
            if(strstr(fileName_token,".txt")){
                printf("INFO: File %s is  have .txt extention\n",fileName_token);
                // checking the file is empty or not
                if(feof(file) != -1){
                    if(insertion_file_name(file_head,fileName_token) == SUCCESS){
                        printf("INFO: insertion file name is Done\n");
                        fclose(file);
                    }
                    else {
                        printf("INFO: insertion file name is Failure\n");
                    }
                }
            }
            else{
                printf("INFO: File %s is not have .txt extention\n",fileName_token);
                continue;
            }
        }
        else{
            printf("ERROR: %s Unable to open file\n",fileName_token);
            continue;
        }
    }
    return SUCCESS;
}