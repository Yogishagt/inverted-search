#include "main.h"
/*function to save the details to a file*/
int save(main_node *hashtable[]){
    // taking a buffer
    char fileName[20];
    printf("INFO: Enter the file name to save the data: ");
    // reading from user
    scanf("%s",fileName);
    // checking the user enterd file name has .txt extension or not
    if(!strstr(fileName,".txt")){
        printf("INFO: Entered file name not having .txt extantion!\n");
        return FAILURE;
    }
    // strcpy(backup,fileName);
    // opening the file
    FILE *file = fopen(fileName,"a");
    // checking the file open or not
    if(file == NULL){
        printf("INFO: Error in opening file!\n");
        return FAILURE;
    }
    // traversing through the hashtable
    for(int i=0;i<27;i++){
        // taking temp pointer to traverse through the linked list
        main_node *mtemp=hashtable[i];
        // traversing
        while(mtemp!=NULL){
            // writing to a file
            fprintf(file, "%c%d%c%s%c%d%c",'#', i, ';',mtemp->word, ';', mtemp->fileCount, ';');
            sub_node *stemp=mtemp->sub_link;
            while(stemp){
                // writing to a file
                fprintf(file,"%s%c%d%c", stemp->file_Name, ';', stemp->word_count, ';');
                stemp=stemp->link;
            }
            fprintf(file,"%c\n",'#');
            // traversing forword
            mtemp=mtemp->main_link;
        }
    }
    // clsoing the file
    fclose(file);
    return SUCCESS;
}