#include "main.h"

int display(main_node *hashtable[]){
    // running a loop
    for(int i=0;i<27;i++){
         // taking temp pointer to traverse through the linked list
        main_node *mtemp=hashtable[i];
        // traversing
        while(mtemp!=NULL){
            // display the details to the user
            printf("index = %d  ",i);
            printf("word = %s   ",mtemp->word);
            printf("file Count = %d     ",mtemp->fileCount);
             // taking temp pointer to traverse through the linked list
            sub_node *stemp=mtemp->sub_link;
            // traversing
            while(stemp){
                // display the details to the user
                printf("file name = %s    ",stemp->file_Name);
                printf("word Count = %d     ",stemp->word_count);
                stemp=stemp->link;
            }
            printf("\n");
            // traversing forword
            mtemp=mtemp->main_link;
        }
    }
    return SUCCESS;
}