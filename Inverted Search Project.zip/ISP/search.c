#include "main.h"
/*Function to search for word is prasent in hashTable*/
int search(main_node *hashtable[]){
    // taking a buffer
    char word[20];
    printf("INFO: Enter a word to search: ");
    // reading input from user
    scanf("%s", word);
    // calculating the index
    int index = tolower(word[0]) % 97; // converting the word to lowercase
    // checking the hashtable has data in index
    if(hashtable[index] == NULL)
        return DATA_NOT_FOUND;

    // taking temp pointer to traverse through the linked list
    main_node *mtemp=hashtable[index];
    // traversing
    while(mtemp){
        // checking wether the user entered word is equal to the word in the linked list
        if(strcmp(word, mtemp->word) == 0){
            printf("\nThe word %s is prasent in %d files\n", word, mtemp->fileCount);
            // taking temp pointer to traverse through the linked list
            sub_node *stemp=mtemp->sub_link;
            // traversing
            while(stemp){
                printf("In %s for %d times\n", stemp->file_Name, stemp->word_count);
                // traversing forword
                stemp=stemp->link;
            }
        }
        mtemp=mtemp->main_link;
    }
    printf("\n");
    // traversing forword
    return SUCCESS;
}